#ifndef __HEADER__BASIC__
#define __HEADER__BASIC__

#ifndef NULL
#define NULL ((void*)0L)
#endif

#endif
