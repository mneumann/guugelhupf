AbstractMethodException = Exception.new("Abstract method called!")
